"""
Main file of the synthetic experiments in GO-UCB paper

Global Optimization with Parametric Function Approximation
Chong Liu, Yu-Xiang Wang
The 40th International Conference on Machine Learning (ICML-2023), Honolulu, HI, 2023, pp. 22113-22136. [ArXiv 2211.09100]

Author: Chong Liu, chongliu.cs@gmail.com
Created on Jan 6, 2023, last modified on May 9, 2025
"""

import os
import argparse
import matplotlib.pyplot as plt
from botorch.acquisition import ExpectedImprovement
from botorch.acquisition import UpperConfidenceBound
from botorch.acquisition import ProbabilityOfImprovement
from botorch.fit import fit_gpytorch_mll
from botorch.models import SingleTaskGP
from botorch.optim import optimize_acqf
from botorch.test_functions import Ackley
from botorch.test_functions import StyblinskiTang
from botorch.test_functions import Rastrigin
from torch.quasirandom import SobolEngine
from gpytorch.constraints import Interval
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.mlls import ExactMarginalLogLikelihood
from goucb_supp import *

parser = argparse.ArgumentParser(description='GO-UCB algorithm')
parser.add_argument('-n', '--n', default=8, type=int)  # number of Phase I random points
parser.add_argument('-t', '--t', default=64, type=int)  # number of Phase II active query points
parser.add_argument('-f', '--f', default=1.0, type=float)
parser.add_argument('-o', '--n_opt', default=2000, type=int)  # steps in optimization
parser.add_argument('-k', '--n_rpt', default=5, type=int)  # number of random trials
parser.add_argument('-s', '--sigma', default=0.01, type=float)  # noise parameter
parser.add_argument('-e', '--eta', default=0.00000000001, type=float)
parser.add_argument('-l', '--l_bound', default=-5.0, type=float)  # left bound of function domain
parser.add_argument('-r', '--r_bound', default=5.0, type=float)  # right bound of function domain
parser.add_argument('-c', '--c', default=0.0000001, type=float)
parser.add_argument('-d', '--d', default=20, type=int)  # input dimension
parser.add_argument('--d_i', default=25, type=int)  # activation function dimension of NN model

args = parser.parse_args()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
dtype = torch.double
SMOKE_TEST = os.environ.get("SMOKE_TEST")

# Test function is the Styblinski-Tang function
fun = StyblinskiTang(dim=args.d, negate=True).to(dtype=dtype, device=device)
fun.bounds[0, :].fill_(args.l_bound)
fun.bounds[1, :].fill_(args.r_bound)
batch_size = 1
n_init = args.n
max_cholesky_size = float("inf")


def eval_objective(x):
    """This is a helper function we use to unnormalize and evalaute a point"""
    return fun(x)


def get_initial_points(dim, n_pts, args, seed=0):
    sobol = SobolEngine(dimension=dim, scramble=True, seed=seed)
    X_init = sobol.draw(n=n_pts).to(dtype=dtype, device=device)
    for i in range(n_pts):
        X_init[i] = args.l_bound + X_init[i] * (args.r_bound - args.l_bound)
    return X_init


# calculate cumulative regret
def cr(max_value, y_seq):
    cr = np.zeros([args.n + args.t])
    tmp = 0
    for i in range(args.n + args.t):
        tmp += max_value - y_seq[i]
        cr[i] = tmp
    return cr


# GP-EI algorithm
def ei(args):

    X_ei = get_initial_points(args.d, args.n, args)
    Y_ei = torch.tensor(
        [eval_objective(x) for x in X_ei], dtype=dtype, device=device
    ).unsqueeze(-1)

    for i in range(args.t):
        likelihood = GaussianLikelihood(noise_constraint=Interval(1e-8, 1e-3))
        model = SingleTaskGP(X_ei, Y_ei, likelihood=likelihood)
        mll = ExactMarginalLogLikelihood(model.likelihood, model)
        fit_gpytorch_mll(mll)

        ei = ExpectedImprovement(model, Y_ei.max(), maximize=True)
        candidate, acq_value = optimize_acqf(
            ei,
            bounds=torch.stack(
                [
                    args.l_bound * torch.ones(args.d, dtype=dtype, device=device),
                    args.r_bound * torch.ones(args.d, dtype=dtype, device=device),
                ]
            ),
            q=batch_size,
            num_restarts=1,
            raw_samples=args.n,
        )
        Y_next = torch.tensor(
            [eval_objective(x) for x in candidate], dtype=dtype, device=device
        ).unsqueeze(-1)

        # Append data
        X_ei = torch.cat((X_ei, candidate), axis=0)
        Y_ei = torch.cat((Y_ei, Y_next), axis=0)
    return X_ei, Y_ei


# GP-UCB algorithm
def ucb(args):

    X_ei = get_initial_points(args.d, args.n, args)
    Y_ei = torch.tensor(
        [eval_objective(x) for x in X_ei], dtype=dtype, device=device
    ).unsqueeze(-1)

    for i in range(args.t):
        likelihood = GaussianLikelihood(noise_constraint=Interval(1e-8, 1e-3))
        model = SingleTaskGP(X_ei, Y_ei, likelihood=likelihood)
        mll = ExactMarginalLogLikelihood(model.likelihood, model)
        fit_gpytorch_mll(mll)

        ei = UpperConfidenceBound(model, beta=0.1, maximize=True)
        candidate, acq_value = optimize_acqf(
            ei,
            bounds=torch.stack(
                [
                    args.l_bound * torch.ones(args.d, dtype=dtype, device=device),
                    args.r_bound * torch.ones(args.d, dtype=dtype, device=device),
                ]
            ),
            q=batch_size,
            num_restarts=1,
            raw_samples=args.n,
        )
        Y_next = torch.tensor(
            [eval_objective(x) for x in candidate], dtype=dtype, device=device
        ).unsqueeze(-1)

        # Append data
        X_ei = torch.cat((X_ei, candidate), axis=0)
        Y_ei = torch.cat((Y_ei, Y_next), axis=0)
    return X_ei, Y_ei


# GO-UCB algorithm in this paper
def go_ucb(args):

    class Net(nn.Module):

        def __init__(self):
            super(Net, self).__init__()
            self.fc1 = nn.Linear(20, 25)
            self.fc2 = nn.Linear(25, 1)

        def forward(self, x):
            x.requires_grad = True
            y = self.fc2(torch.sigmoid(self.fc1(x)))
            return y

    d_i = args.d_i
    d_w = args.d * d_i + 2 * d_i + 1
    X = np.zeros([args.n + args.t, args.d])
    Y = np.zeros([args.n + args.t])
    W = np.zeros([args.t + 1, d_w])
    W_grad = np.zeros([args.t + 1, d_w])
    lambda_ = np.sqrt(args.t) * (np.log(args.t)) ** 2

    X_init = get_initial_points(args.d, args.n, args)
    Y_init = torch.tensor(
        [eval_objective(x) for x in X_init], dtype=dtype, device=device
    ).unsqueeze(-1)

    X[:args.n, :] = X_init.cpu().detach().numpy()
    Y[:args.n] = np.squeeze(Y_init.cpu().detach().numpy())

    w0 = oracle(X[:args.n, :], Y[:args.n], args)
    w0_grad, _ = get_grad(w0, X[args.n - 1, :], args)
    W[0, :] = w0
    W_grad[0, :] = w0_grad
    Sigma = lambda_ * np.identity(d_w)
    Sigma_tmp = np.zeros(d_w)
    x_idx = np.where(Y == np.max(Y[:args.n]))
    best_x = X[x_idx[0][0], :]

    for i in range(args.t):
        print('This is ' + str(i + args.n) + '/' + str(args.t + args.n) + 'th iteration of GO-UCB.')
        w_i = W[i, :]
        w_i_grad = W_grad[i, :]
        w_i_grad = np.expand_dims(w_i_grad, axis=1)
        Sigma += w_i_grad @ w_i_grad.T
        Sigma_tmp += np.squeeze((Y[args.n + i - 1] - f_hat(X[args.n + i - 1, :], w_i, args)) * w_i_grad) + (
                    w_i_grad @ w_i_grad.T) @ w_i
        wt = np.linalg.inv(Sigma) @ (lambda_ * w0 + Sigma_tmp)
        W[i + 1, :] = wt
        if i == 0:
            xt = opt_acq(args, wt, best_x, Sigma, i, args.c, args.f)
        else:
            xt = opt_acq(args, wt, X[args.n + i - 1, :], Sigma, i, args.c, args.f)
        wt_grad, _ = get_grad(wt, xt, args)
        W_grad[i + 1, :] = wt_grad
        X[args.n + i] = xt
        yt = eval_objective(torch.from_numpy(xt))
        Y[args.n + i] = yt.cpu().detach().numpy()

    return X, torch.from_numpy(Y)


result_gp_mat = np.zeros([args.n + args.t, args.n_rpt])
result_go_mat = np.zeros([args.n + args.t, args.n_rpt])
result_ei_mat = np.zeros([args.n + args.t, args.n_rpt])

for k in range(args.n_rpt):
    X_goucb, Y_goucb = go_ucb(args)
    X_ei, Y_ei = ei(args)
    X_ucb, Y_ucb = ucb(args)
    result_go_mat[:, k] = cr(fun.optimal_value, Y_goucb)
    result_gp_mat[:, k] = cr(fun.optimal_value, Y_ucb)
    result_ei_mat[:, k] = cr(fun.optimal_value, Y_ei)

names = ["GP-UCB", "GP-EI", "GO-UCB"]
runs = [result_gp_mat, result_ei_mat, result_go_mat]

x = range(1, 1 + args.n + args.t)
for name, run in zip(names, runs):
    plt.plot(x, np.mean(run, axis=1), marker="", lw=3, label=name)
    plt.fill_between(x=x,
                     y1=np.mean(run, axis=1) - 1.96 * np.std(run, axis=1) / np.sqrt(args.n_rpt),
                     y2=np.mean(run, axis=1) + 1.96 * np.std(run, axis=1) / np.sqrt(args.n_rpt),
                     alpha=0.2)

plt.legend()
plt.grid(True)
plt.xlabel('Time Horizon')
plt.ylabel('Cumulative Regret')
plt.show()
