"""
Supplementary file of the synthetic experiments in GO-UCB paper

Global Optimization with Parametric Function Approximation
Chong Liu, Yu-Xiang Wang
The 40th International Conference on Machine Learning (ICML-2023), Honolulu, HI, 2023, pp. 22113-22136. [ArXiv 2211.09100]

Author: Chong Liu, chongliu.cs@gmail.com
Created on Jan 6, 2023, last modified on May 9, 2025
"""


import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


# define a two-layer neural network as the model of GO-UCB
class Net(nn.Module):

    def __init__(self):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(20, 25)
        self.fc2 = nn.Linear(25, 1)

    def forward(self, x):
        x.requires_grad = True
        y = self.fc2(torch.sigmoid(self.fc1(x)))
        return y


# optimizing acquisition function
def opt_acq(args, wt, x, Sigma, t, C, F):
    lr_w = 1e-4
    lr_x = 1e-4
    beta_t = (args.d ** 3) * (F ** 4) * (t+1) * np.log(2+t) * (np.log(args.t)) ** 2 / args.t
    beta_t = C * beta_t
    print('beta_t:')
    print(beta_t)
    w = wt.copy()
    for i in range(args.n_opt):
        _, x_grad = get_grad(w, x, args)
        x += lr_x * x_grad
        for j in range(int(np.shape(x)[0])):
            if x[j] < args.l_bound:
                x[j] = args.l_bound
            if x[j] > args.r_bound:
                x[j] = args.r_bound

        w_grad, _ = get_grad(w, x, args)
        w += lr_w * w_grad
        w_copy = w.copy()
        w_copy_wt = np.expand_dims(w_copy - wt, axis=1)
        tmp = w_copy_wt.T @ Sigma @ w_copy_wt

        if tmp[0][0] > beta_t:
            alpha_ = beta_t / tmp
            w = wt + alpha_ * (w - wt)
            w = np.squeeze(w)

    return x


# train w for x_vec, y_vec
def oracle(x_vec, y_vec, args):
    net = Net()
    net.double()
    optimizer = optim.SGD(net.parameters(), lr=args.eta)
    criterion = nn.MSELoss()
    x_vec = torch.from_numpy(x_vec)
    y_vec = torch.from_numpy(y_vec)
    optimizer.zero_grad()
    for i in range(args.n_opt):
        output = net(x_vec)
        output = torch.squeeze(output)
        loss = criterion(output, y_vec)
        loss.backward()
        optimizer.step()
    w = e2v(net.fc1.weight, net.fc1.bias, net.fc2.weight, net.fc2.bias)
    return w.detach().numpy()


# gradient wrt w and x
def get_grad(w, x, args):
    w = torch.tensor(w)
    x = torch.tensor(x)
    w1, b1, w2, b2 = v2e(w, args.d, args.d_i)
    net = Net()
    net.double()
    net.fc1.weight = torch.nn.Parameter(w1)
    net.fc1.bias = torch.nn.Parameter(b1)
    net.fc2.weight = torch.nn.Parameter(w2)
    net.fc2.bias = torch.nn.Parameter(b2)
    output = net(x)
    net.zero_grad()
    output.backward()
    g_w1 = torch.reshape(net.fc1.weight.grad, (-1,))
    g_b1 = net.fc1.bias.grad
    g_w2 = torch.reshape(net.fc2.weight.grad, (-1,))
    g_b2 = net.fc2.bias.grad
    if g_b2.ndim == 0:
        g_b2 = torch.unsqueeze(g_b2, 0)
    g_vec = torch.cat((g_w1, g_b1, g_w2, g_b2), 0)
    g_vec = g_vec.detach().numpy()
    return g_vec, x.grad.detach().numpy()


# parametric model given weights
def f_hat(x, w, args):
    w = torch.tensor(w)
    w1, b1, w2, b2 = v2e(w, args.d, args.d_i)
    x = torch.from_numpy(x)
    net_hat = Net()
    net_hat.double()
    net_hat.fc1.weight = torch.nn.Parameter(w1)
    net_hat.fc1.bias = torch.nn.Parameter(b1)
    net_hat.fc2.weight = torch.nn.Parameter(w2)
    net_hat.fc2.bias = torch.nn.Parameter(b2)
    return net_hat(x).detach().numpy()


# noisy zeroth order feedback
def f_obs(x, sigma):
    return f(x) + np.random.normal(0.0, sigma, 1)


# realizable nn function
def f(x):
    x = torch.from_numpy(x)
    net_true = Net()
    net_true.double()
    net_true.fc1.weight.data.fill_(1)
    net_true.fc1.bias.data.fill_(1)
    net_true.fc2.weight.data.fill_(1)
    net_true.fc2.bias.data.fill_(1)
    return net_true(x).detach().numpy()


# elements to vector
def e2v(w_1, b_1, w_2, b_2):
    v_w1 = torch.reshape(w_1, (-1,))
    v_w2 = torch.reshape(w_2, (-1,))
    v_vec = torch.cat((v_w1, b_1, v_w2, b_2), 0)
    return v_vec


# vector to elements
def v2e(w, d, d_i):
    w1 = torch.reshape(w[:d*d_i], (d_i, d))
    b1 = w[d*d_i: d*d_i + d_i]
    w2 = w[d*d_i + d_i: d*d_i + 2*d_i]
    b2 = w[d*d_i + 2*d_i]
    return w1, b1, w2, b2
