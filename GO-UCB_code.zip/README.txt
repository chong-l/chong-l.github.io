This the README file of the synthetic experiments in GO-UCB paper

Global Optimization with Parametric Function Approximation
Chong Liu, Yu-Xiang Wang
The 40th International Conference on Machine Learning (ICML-2023), Honolulu, HI, 2023, pp. 22113-22136. [ArXiv 2211.09100]

Author: Chong Liu, chongliu.cs@gmail.com
Created on Jan 6, 2023, last modified on May 9, 2025

Required environments:
python => 3.9
numpy => 1.23.4
torch => 1.13.1
botorch => 0.8.1
gpytorch => 1.9.1
matplotlib => 3.4.3