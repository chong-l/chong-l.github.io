"""
Algorithms of Doubly Robust Crowdsourcing
Author: Chong Liu, chongliu@cs.ucsb.edu
Created on Oct 15, 2020, last modified on Feb 19, 2022
"""

import numpy as np
from utils import voting_from_vector


def doubly_robust_ais(pseudo_label_matrix, confusion_matrix_ds, prior_probability_ds, test_label_matrix, confidence_margin, sparsity_rate):

    [n_instances, n_workers] = np.shape(pseudo_label_matrix)
    n_classes = np.shape(confusion_matrix_ds)[1]
    # probability_prediction = np.zeros([n_instances, n_classes])
    cost = 0
    pred_label = np.zeros([n_instances])

    for j in range(n_instances):
        voting_vec = np.log(prior_probability_ds) / n_workers
        # probability_prediction[j, :] = np.log(prior_probability_ds) / n_workers
        confidence_vector = np.log(prior_probability_ds) / n_workers

        for i in range(n_workers):
            current_pseudo_label = int(pseudo_label_matrix[j, i])
            if current_pseudo_label > 0:
                confidence_vector += np.log(confusion_matrix_ds[i, :, current_pseudo_label-1]) / n_workers

        sorted_confidence = np.sort(confidence_vector)
        max_item = sorted_confidence[n_classes-1]
        submax_item = sorted_confidence[n_classes-2]
        confidence_current = submax_item + np.log(np.exp(max_item - submax_item)-1)

        if confidence_current > np.log(confidence_margin):

            for i in range(n_workers):
                current_pseudo_label = int(pseudo_label_matrix[j, i])
                if current_pseudo_label > 0:
                    voting_vec += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                    # probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers

        else:

            # cost += n_workers * sparsity_rate
            for i in range(n_workers):

                current_pseudo_label = int(pseudo_label_matrix[j, i])
                current_observed_label = int(test_label_matrix[j, i])
                if current_pseudo_label > 0:
                    voting_vec += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                    # probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                    if current_observed_label > 0:
                        cost += 1
                        diff = np.log((confusion_matrix_ds[i, :, current_observed_label - 1]) /
                                      (confusion_matrix_ds[i, :, current_pseudo_label - 1]))
                        # probability_prediction[j, :] += diff / (n_workers * sparsity_rate)
                        voting_vec += diff / (n_workers * sparsity_rate)
                else:
                    if current_observed_label > 0:
                        cost += 1
                        voting_vec += np.log(confusion_matrix_ds[i, :, current_observed_label - 1]) / \
                                                        (n_workers * sparsity_rate)
                        # probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_observed_label - 1]) / (n_workers * sparsity_rate)
        pred_label[j] = voting_from_vector(voting_vec)
    # predicted_label = np.argmax(probability_prediction, 1) + np.ones(n_instances)

    return pred_label, cost/n_instances


def doubly_robust_ais_aws(pseudo_label_matrix, confusion_matrix_ds, prior_probability_ds, test_label_matrix, confidence_margin, n_rounds):
    [n_instances, n_workers] = np.shape(pseudo_label_matrix)
    n_classes = np.shape(confusion_matrix_ds)[1]
    # probability_prediction = np.zeros([n_instances, n_classes])
    cost = 0
    pred_label = np.zeros([n_instances])

    for j in range(n_instances):
        # probability_prediction[j, :] = np.log(prior_probability_ds) / n_workers
        voting_vec = np.log(prior_probability_ds) / n_workers
        confidence_vector = np.log(prior_probability_ds) / n_workers

        for i in range(n_workers):
            current_pseudo_label = int(pseudo_label_matrix[j, i])
            if current_pseudo_label > 0:
                confidence_vector += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers

        sorted_confidence = np.sort(confidence_vector)
        max_item = sorted_confidence[n_classes - 1]
        submax_item = sorted_confidence[n_classes - 2]
        confidence_current = submax_item + np.log(np.exp(max_item - submax_item) - 1)

        if confidence_current > np.log(confidence_margin):

            for i in range(n_workers):
                current_pseudo_label = int(pseudo_label_matrix[j, i])
                if current_pseudo_label > 0:
                    voting_vec += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                    # probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers

        else:
            worker_score = np.zeros([n_workers])

            for i in range(n_workers):
                current_pseudo_label = int(pseudo_label_matrix[j, i])
                if current_pseudo_label > 0:
                    labeling_prob = confusion_matrix_ds[i, :, current_pseudo_label - 1]
                    labeling_prob = np.sort(labeling_prob)
                    worker_score[i] = labeling_prob[n_classes - 1] - labeling_prob[n_classes - 2]
                else:
                    worker_score[i] = 1e-6

            worker_score = n_rounds * worker_score / np.sum(worker_score)
            ita_vector = 1 / worker_score
            sorted_ita_vector = np.sort(ita_vector)
            compare_result = np.zeros([n_workers])
            for i in range(n_workers):
                ita = sorted_ita_vector[i]
                compare_result[i] = np.abs(ita - (n_workers - i - 1) / np.sqrt(n_workers))
            ita_index = np.argmin(compare_result)
            ita_tsd = ita_vector[ita_index]

            for i in range(n_workers):
                current_pseudo_label = int(pseudo_label_matrix[j, i])
                if current_pseudo_label > 0:
                    voting_vec += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                    # probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                    die = np.random.rand(1)
                    if die < worker_score[i]:

                        current_observed_label = int(test_label_matrix[j, i])
                        if current_observed_label > 0:
                            cost += 1
                            diff = np.log((confusion_matrix_ds[i, :, current_observed_label - 1]) / confusion_matrix_ds[i, :,
                                                                                            current_pseudo_label - 1])
                            if worker_score[i] > ita_tsd:
                                voting_vec += diff * ita_tsd / n_workers
                                # probability_prediction[j, :] += diff * ita_tsd / n_workers
                            else:
                                voting_vec += diff * worker_score[i] / n_workers
                                # probability_prediction[j, :] += diff * worker_score[i] / n_workers
                else:
                    die = np.random.rand(1)
                    if die < worker_score[i]:
                        current_observed_label = int(test_label_matrix[j, i])
                        if current_observed_label > 0:
                            cost += 1
                            diff = np.log(confusion_matrix_ds[i, :, current_observed_label - 1])
                            if worker_score[i] > ita_tsd:
                                voting_vec += diff * ita_tsd / n_workers
                                # probability_prediction[j, :] += diff * ita_tsd / n_workers
                            else:
                                voting_vec += diff * worker_score[i] / n_workers
                                # probability_prediction[j, :] += diff * worker_score[i] / n_workers
        pred_label[j] = voting_from_vector(voting_vec)
    # predicted_label = np.argmax(probability_prediction, 1) + np.ones(n_instances)

    return pred_label, cost/n_instances


def doubly_robust_aws(pseudo_label_matrix, confusion_matrix_ds, prior_probability_ds, test_label_matrix, n_rounds):

    [n_instances, n_workers] = np.shape(pseudo_label_matrix)
    n_classes = np.shape(confusion_matrix_ds)[1]
    # probability_prediction = np.zeros([n_instances, n_classes])
    pred_label = np.zeros([n_instances])
    cost = 0

    for j in range(n_instances):

        voting_vec = np.log(prior_probability_ds) / n_workers
        # probability_prediction[j, :] = np.log(prior_probability_ds) / n_workers
        worker_score = np.zeros([n_workers])

        for i in range(n_workers):
            current_pseudo_label = int(pseudo_label_matrix[j, i])
            if current_pseudo_label > 0:
                labeling_prob = confusion_matrix_ds[i, :, current_pseudo_label - 1]
                labeling_prob = np.sort(labeling_prob)
                worker_score[i] = labeling_prob[n_classes - 1] - labeling_prob[n_classes - 2]
            else:
                worker_score[i] = 1e-6

        worker_score = n_rounds * worker_score / np.sum(worker_score)
        ita_vector = 1/worker_score
        sorted_ita_vector = np.sort(ita_vector)
        compare_result = np.zeros([n_workers])
        for i in range(n_workers):
            ita = sorted_ita_vector[i]
            compare_result[i] = np.abs(ita - (n_workers - i - 1)/np.sqrt(n_workers))
        ita_index = np.argmin(compare_result)
        ita_tsd = ita_vector[ita_index]

        for i in range(n_workers):
            current_pseudo_label = int(pseudo_label_matrix[j, i])
            if current_pseudo_label > 0:
                voting_vec += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                # probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1]) / n_workers
                die = np.random.rand(1)
                if die < worker_score[i]:
                    current_observed_label = int(test_label_matrix[j, i])
                    if current_observed_label > 0:
                        cost += 1
                        diff = np.log((confusion_matrix_ds[i, :, current_observed_label - 1]) / confusion_matrix_ds[i, :, current_pseudo_label - 1])
                        if worker_score[i] > ita_tsd:
                            voting_vec += diff * ita_tsd / n_workers
                            # probability_prediction[j, :] += diff * ita_tsd / n_workers
                        else:
                            voting_vec += diff * worker_score[i] / n_workers
                            # probability_prediction[j, :] += diff * worker_score[i] / n_workers
            else:
                die = np.random.rand(1)
                if die < worker_score[i]:
                    current_observed_label = int(test_label_matrix[j, i])
                    if current_observed_label > 0:
                        cost += 1
                        diff = np.log(confusion_matrix_ds[i, :, current_observed_label - 1])
                        if worker_score[i] > ita_tsd:
                            voting_vec += diff * ita_tsd / n_workers
                            # probability_prediction[j, :] += diff * ita_tsd / n_workers
                        else:
                            voting_vec += diff * worker_score[i] / n_workers
                            # probability_prediction[j, :] += diff * worker_score[i] / n_workers
        pred_label[j] = voting_from_vector(voting_vec)
    # predicted_label = np.argmax(probability_prediction, 1) + np.ones(n_instances)

    return pred_label, cost/n_instances


# Direct method model samples some of the workers use the feature matrix to do the label inference
def direct_method(label_matrix_p, confusion_matrix_ds, prior_probability_ds):
    [n_item, n_worker] = np.shape(label_matrix_p)
    n_class = np.shape(confusion_matrix_ds)[1]
    pred_label = np.zeros([n_item])
    # probability_prediction = np.zeros([n_instances, n_classes])
    for j in range(n_item):
        voting_vec = np.log(prior_probability_ds)
        # probability_prediction[j, :] = np.log(prior_probability_ds) / n_workers
        for i in range(n_worker):
            current_observed_label = int(label_matrix_p[j, i])
            if current_observed_label > 0 and np.sum(confusion_matrix_ds[i, :, current_observed_label - 1]) > 0:
                voting_vec += np.log(confusion_matrix_ds[i, :, current_observed_label - 1])
        pred_label[j] = voting_from_vector(voting_vec)
    # predicted_label = np.argmax(probability_prediction, 1) + np.ones(n_instances)
    return pred_label


# Importance sampling model samples some of the workers to label the items and aggregate the final results
def importance_sampling_ds(confusion_matrix_ds, prior_probability_ds, label_matrix, s_rate):
    [n_item, n_worker] = np.shape(label_matrix)
    n_class = int(np.max(label_matrix))
    pred_label = np.zeros([n_item])
    # probability_prediction = np.zeros([n_instances, n_classes])
    for j in range(n_item):
        voting_vec = np.log(prior_probability_ds)
        # probability_prediction[j, :] = np.log(prior_probability_ds) / n_workers
        # sparsity_rate = np.sum(test_label_matrix[j, :] != 0) / n_workers
        for i in range(n_worker):
            current_observed_label = int(label_matrix[j, i])
            if current_observed_label > 0:
                # if np.sum(confusion_matrix_ds[i, :, current_observed_label - 1]) < 0.1:
                #     print(confusion_matrix_ds[i, :, current_observed_label - 1])
                # probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_observed_label - 1]) / (n_workers * sparsity_rate)
                voting_vec += np.log(confusion_matrix_ds[i, :, current_observed_label - 1]) / s_rate
        pred_label[j] = voting_from_vector(voting_vec)
    # predicted_label = np.argmax(probability_prediction, 1) + np.ones(n_instances)
    return pred_label


# Majority Voting is the baseline method for crowdsourcing problem
def majority_voting(label_matrix):
    [n_item, n_worker] = np.shape(label_matrix)
    n_class = int(np.max(label_matrix))
    pred_label = np.zeros([n_item])
    for j in range(n_item):
        if np.sum(label_matrix[j, :]) > 0:
            voting_vector = np.zeros([n_class])
            for i in range(n_worker):
                current_label = int(label_matrix[j, i])
                if current_label > 0:
                    voting_vector[current_label - 1] += 1
            pred_label[j] = voting_from_vector(voting_vector)
            # print(voting_vector)
        else:
            pred_label[j] = np.random.randint(1, n_class+1, size=1)
    return pred_label


def doubly_robust_mv(label_matrix_p, label_matrix, s_rate):
    [n_item, n_worker] = np.shape(label_matrix)
    n_class = int(np.max(label_matrix))
    pred_label = np.zeros([n_item])
    for j in range(n_item):
        voting_vector = np.zeros([n_class])
        for i in range(n_worker):
            current_pseudo_label = int(label_matrix_p[j, i])
            current_observed_label = int(label_matrix[j, i])
            if current_pseudo_label > 0:
                voting_vector[current_pseudo_label - 1] += 1
                if current_observed_label > 0:
                    voting_vector[current_pseudo_label - 1] -= 1 / s_rate
                    voting_vector[current_observed_label - 1] += 1 / s_rate
            else:
                if current_observed_label > 0:
                    voting_vector[current_observed_label - 1] += 1 / s_rate
        # print(voting_vector)
        pred_label[j] = voting_from_vector(voting_vector)
    return pred_label


def ideal_world(confusion_matrix_ds, prior_probability_ds, test_label_matrix):
    [n_instances, n_workers] = np.shape(test_label_matrix)
    n_classes = int(np.max(test_label_matrix))
    probability_prediction = np.zeros([n_instances, n_classes])
    for j in range(n_instances):
        probability_prediction[j, :] = np.log(prior_probability_ds) / n_workers
        for i in range(n_workers):
            current_observed_label = int(test_label_matrix[j, i])
            probability_prediction[j, :] += np.log(confusion_matrix_ds[i, :, current_observed_label - 1]) / n_workers
    predicted_label = np.argmax(probability_prediction, 1) + np.ones(n_instances)
    return predicted_label


# Main part of Dawid-Skene model
def dawid_skene(dataset_matrix, tolerance, max_iteration):
    counts = dataset_to_counts(dataset_matrix)
    [n_instances, n_workers, n_classes] = np.shape(counts)
    probability_prediction = initialize(counts)
    prior_probability_old = np.zeros([n_classes])
    confusion_matrix_old = np.zeros([n_workers, n_classes, n_classes])
    for i in range(max_iteration):
        (prior_probability, confusion_matrix) = m_step(counts, probability_prediction)
        probability_prediction = e_step(counts, prior_probability, confusion_matrix)
        prior_probability_diff = np.sum(np.abs(prior_probability - prior_probability_old))
        confusion_matrix_diff = np.sum(np.abs(confusion_matrix - confusion_matrix_old))
        if prior_probability_diff < tolerance and confusion_matrix_diff < tolerance:
            break
        prior_probability_old = prior_probability
        confusion_matrix_old = confusion_matrix
    output_label = np.zeros([n_instances])
    for j in range(n_instances):
        output_label[j] = voting_from_vector(probability_prediction[j, :])
    # output_label = np.argmax(probability_prediction, 1) + np.ones(n_instances)
    return probability_prediction, output_label, confusion_matrix, prior_probability


def doubly_robust_ds(label_matrix_p, confusion_matrix_ds, prior_probability_ds, label_matrix_stu, s_rate):
    [n_item, n_worker] = np.shape(label_matrix_p)
    n_class = np.shape(confusion_matrix_ds)[1]
    pred_label = np.zeros([n_item])
    cost = 0
    # probability_prediction = np.zeros([n_instances, n_classes])
    for j in range(n_item):
        voting_vec = np.log(prior_probability_ds)
        # probability_prediction[j, :] = np.log(prior_probability_ds)
        # sparsity_rate = np.sum(test_label_matrix[j, :] != 0) / n_workers
        for i in range(n_worker):
            current_pseudo_label = int(label_matrix_p[j, i])
            current_observed_label = int(label_matrix_stu[j, i])
            if current_pseudo_label > 0:
                voting_vec += np.log(confusion_matrix_ds[i, :, current_pseudo_label - 1])
                if current_observed_label > 0:
                    cost += 1
                    diff = np.log((confusion_matrix_ds[i, :, current_observed_label - 1]) / (confusion_matrix_ds[i, :, current_pseudo_label - 1]))
                    voting_vec += diff / s_rate
            else:
                if current_observed_label > 0:
                    cost += 1
                    voting_vec += np.log(confusion_matrix_ds[i, :, current_observed_label - 1]) / s_rate
        pred_label[j] = voting_from_vector(voting_vec)
    return pred_label, cost/n_item


# Part 1 of Dawid-Skene model: Change the dataset matrix to counts
def dataset_to_counts(dataset_matrix):
    [n_instances, n_workers] = np.shape(dataset_matrix)
    n_classes = int(np.max(dataset_matrix))
    counts = np.zeros([n_instances, n_workers, n_classes])
    for j in range(n_instances):
        for i in range(n_workers):
            for k in range(n_classes):
                if dataset_matrix[j, i] == k + 1:
                    counts[j, i, k] += 1
    return counts


# Part 2 of Dawid-Skene model: Initialize the prediction probability matrix with averaging
def initialize(counts):
    [n_instances, _, n_classes] = np.shape(counts)
    counts_sums = np.sum(counts, 1)
    probability_prediction = np.zeros([n_instances, n_classes])
    for j in range(n_instances):
        if np.sum(counts_sums[j, :]) > 0:
            probability_prediction[j, :] = counts_sums[j, :] / np.sum(counts_sums[j, :], dtype=float)
        else:
            probability_prediction[j, :] = np.ones([n_classes]) / n_classes
    return probability_prediction


# Part 3 of Dawid-Skene model
# M step of EM
# Estimate the confusion matrix and prior probability
# Confusion matrix means the probability such that worker i assign an item in the class j to class l
# The 2nd entry of confusion matrix is the true label while the 3rd is the observed label
def m_step(counts, probability_prediction):
    [n_instances, n_workers, n_classes] = np.shape(counts)
    prior_probability = np.sum(probability_prediction, 0) / float(n_instances)
    confusion_matrix = np.zeros([n_workers, n_classes, n_classes])

    for i in range(n_workers):
        for j in range(n_classes):
            for l in range(n_classes):
                confusion_matrix[i, j, l] = np.dot(probability_prediction[:, j], counts[:, i, l])
            sum_over_counts = np.sum(confusion_matrix[i, j, :])

            if sum_over_counts > 0:
                confusion_matrix[i, j, :] = (confusion_matrix[i, j, :] + np.ones(n_classes)) / float(
                    sum_over_counts + n_classes)
            if np.sum(confusion_matrix[i, j, :]) < 0.01:
                confusion_matrix[i, j, :] += np.ones(n_classes) / n_classes

    return prior_probability, confusion_matrix


# Part 4 of Dawid-Skene model
# E step of EM
# Estimate the probability an item belonging to a certain class
def e_step(counts, prior_probability, confusion_matrix):
    [n_instances, _, n_classes] = np.shape(counts)
    probability_prediction = np.zeros([n_instances, n_classes])

    for i in range(n_instances):
        for j in range(n_classes):
            tmp = prior_probability[j]
            tmp *= np.prod(np.power(confusion_matrix[:, j, :], counts[i, :, :]))
            probability_prediction[i, j] = tmp

        instance_sum = np.sum(probability_prediction[i, :])
        if instance_sum > 0:
            probability_prediction[i, :] = probability_prediction[i, :] / float(instance_sum)

    return probability_prediction
