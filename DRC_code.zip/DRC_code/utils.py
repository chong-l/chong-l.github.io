"""
Utility functions of Doubly Robust Crowdsourcing
Author: Chong Liu, chongliu@cs.ucsb.edu
Created on Oct 15, 2020, last modified on Feb 19, 2022
"""

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.datasets import load_svmlight_file


def voting_from_vector(voting_vec):
    if np.sum(voting_vec == np.max(voting_vec)) > 1:
        candidate_label = np.where(voting_vec == np.max(voting_vec))[0]
        voted_label = np.random.choice(candidate_label, 1) + 1
    else:
        voted_label = np.argmax(voting_vec) + 1
    return voted_label


# Create crowdsoucring dataset from existing classification datasets
def create_syn_dataset(dataset_name, n_workers):
    feature_matrix, true_label = load_svmlight_file(dataset_name + '.txt')
    [n_instances, n_features] = np.shape(feature_matrix)
    if min(true_label) == 0:
        true_label += np.ones([n_instances])

    train_index = np.loadtxt(dataset_name + '_train_index.txt', delimiter=',')
    train_index = train_index.astype(int)
    test_index = np.loadtxt(dataset_name + '_test_index.txt', delimiter=',')
    test_index = test_index.astype(int)

    n_train = round(0.5 * n_instances)
    n_test = n_instances - n_train
    train_feature_matrix = feature_matrix[train_index, :]
    train_true_label = true_label[train_index]
    test_feature_matrix = feature_matrix[test_index, :]
    test_true_label = true_label[test_index]
    label_matrix = np.zeros([n_test, n_workers])

    for i in range(n_workers):
        clf = tree.DecisionTreeClassifier(max_depth=5)
        feature_sampling_index = np.random.randint(n_features, size=int(np.log(n_features)))
        label_matrix[:, i] = clf.fit(train_feature_matrix[:, feature_sampling_index], train_true_label).predict(
            test_feature_matrix[:, feature_sampling_index])

    return label_matrix, test_true_label, test_feature_matrix


# teacher & student dataset split
def split_teacher_student(feature_matrix, label_matrix, true_label_list, teacher_rate):
    n_item = np.shape(feature_matrix)[0]
    t_index = np.random.choice(n_item, round(teacher_rate * n_item), replace=False)
    s_index = list(set(range(n_item)) - set(t_index))
    label_matrix_t = label_matrix[t_index, :]
    feature_matrix_t = feature_matrix[t_index, :]
    label_matrix_s = label_matrix[s_index, :]
    true_label_s = true_label_list[s_index]
    feature_matrix_s = feature_matrix[s_index, :]
    return feature_matrix_t, label_matrix_t, feature_matrix_s, label_matrix_s, true_label_s


# generate pseudo_label_matrix, label_matrix_p
def gen_pseduo_label_matrix(args, clf_type, feature_matrix_t, label_matrix_t, feature_matrix_s):
    n_item_s = np.shape(feature_matrix_s)[0]
    n_worker = np.shape(label_matrix_t)[1]
    n_class = int(np.max(label_matrix_t))
    label_matrix_p = np.zeros([n_item_s, n_worker])
    if clf_type == 'dt':
        clf = tree.DecisionTreeClassifier(max_depth=args.depth)
        # clf = tree.DecisionTreeClassifier()
    elif clf_type == 'lr':
        clf = LogisticRegression()
        # clf = LogisticRegression(penalty='l1', solver='liblinear', multi_class='auto')
    elif clf_type == 'gnb':
        clf = GaussianNB()

    for i in range(n_worker):
        if np.sum(label_matrix_t[:, i]) > 0:
            temp = label_matrix_t[:, i][label_matrix_t[:, i] != 0]
            if np.shape(temp)[0] < args.threshold * n_item_s:
                # pseudo_label_matrix[:, i] = np.unique(temp) * np.ones([n_test_instances])
                # label_matrix_p[:, i] = np.random.randint(1, 1+n_class, size=n_item_s)
                label_matrix_p[:, i] = np.zeros([n_item_s])
            else:
                train_use_index = np.asarray(np.nonzero(label_matrix_t[:, i])[0])
                train_use_label = label_matrix_t[train_use_index, i]
                train_use_feature = feature_matrix_t[train_use_index, :]
                label_matrix_p[:, i] = clf.fit(train_use_feature, train_use_label).predict(feature_matrix_s)
        else:
            # label_matrix_p[:, i] = np.random.randint(1, 1+n_class, size=n_item_s)
            label_matrix_p[:, i] = np.zeros([n_item_s])
    return label_matrix_p


# generate pseudo_label_matrix, label_matrix_p
def gen_pseduo_label_matrix_syn(args, clf_type, feature_matrix_t, label_matrix_t, feature_matrix_s):
    n_item_s = np.shape(feature_matrix_s)[0]
    n_worker = np.shape(label_matrix_t)[1]
    n_class = int(np.max(label_matrix_t))
    label_matrix_p = np.zeros([n_item_s, n_worker])
    if clf_type == 'dt':
        clf = tree.DecisionTreeClassifier(max_depth=args.depth)
        # clf = tree.DecisionTreeClassifier()
    elif clf_type == 'lr':
        clf = LogisticRegression()
        # clf = LogisticRegression(penalty='l1', solver='liblinear', multi_class='auto')
    elif clf_type == 'gnb':
        clf = GaussianNB()

    for i in range(n_worker):
        if np.sum(label_matrix_t[:, i]) > 0:
            temp = label_matrix_t[:, i][label_matrix_t[:, i] != 0]
            if np.shape(temp)[0] < args.threshold * n_item_s:
                # pseudo_label_matrix[:, i] = np.unique(temp) * np.ones([n_test_instances])
                # label_matrix_p[:, i] = np.random.randint(1, 1+n_class, size=n_item_s)
                label_matrix_p[:, i] = np.zeros([n_item_s])
            else:
                train_use_index = np.asarray(np.nonzero(label_matrix_t[:, i])[0])
                train_use_label = label_matrix_t[train_use_index, i]
                train_use_feature = feature_matrix_t[train_use_index, :]
                label_matrix_p[:, i] = clf.fit(train_use_feature.toarray(), train_use_label).predict(feature_matrix_s.toarray())
        else:
            # label_matrix_p[:, i] = np.random.randint(1, 1+n_class, size=n_item_s)
            label_matrix_p[:, i] = np.zeros([n_item_s])
    return label_matrix_p


def create_sampled_pseudo_matrix(label_matrix_p, label_matrix_stu):
    [n_item, n_worker] = np.shape(label_matrix_stu)
    label_matrix_p_sampled = np.zeros([n_item, n_worker])
    for j in range(n_item):
        for i in range(n_worker):
            if label_matrix_stu[j, i] > 0:
                label_matrix_p_sampled[j, i] = label_matrix_p[j, i]
    return label_matrix_p_sampled


def create_sampled_label_matrix(label_matrix, s_rate):
    [n_item, n_worker] = np.shape(label_matrix)
    label_matrix_sampled = np.zeros([n_item, n_worker])
    for j in range(n_item):
        for i in range(n_worker):
            if label_matrix[j, i] > 0:
                if np.random.rand(1) < s_rate:
                    label_matrix_sampled[j, i] = label_matrix[j, i]
    return label_matrix_sampled
