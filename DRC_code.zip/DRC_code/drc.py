"""
Doubly Robust Crowdsourcing on Segment datasets
Author: Chong Liu, chongliu@cs.ucsb.edu
Created on Oct 15, 2020, last modified on Feb 19, 2022
"""

from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
import numpy as np
import argparse
import matplotlib.pyplot as plt

from utils import create_syn_dataset
from utils import gen_pseduo_label_matrix
from utils import create_sampled_label_matrix
from utils import create_sampled_pseudo_matrix
from utils import split_teacher_student

from algs import majority_voting
from algs import doubly_robust_mv
from algs import dawid_skene
from algs import doubly_robust_ds
from algs import importance_sampling_ds
from algs import direct_method

parser = argparse.ArgumentParser(description='Doubly Robust Crowdsourcing')
parser.add_argument('-d', '--dataset', default='segment', type=str)
parser.add_argument('-r', '--n_rpt', default=20, type=int)
parser.add_argument('-w', '--n_worker', default=50, type=int)
parser.add_argument('-c', '--clf', default='dt', type=str)
parser.add_argument('--depth', default=3, type=int)
parser.add_argument('-tr', '--teacher_rate', default=0.5, type=float)
parser.add_argument('-s', '--s_rate', default='0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0', type=str)
parser.add_argument('-t', '--threshold', default=0.3, type=float)


def main():
    args = parser.parse_args()

    # dataset processing
    [label_matrix, true_label_list, feature_matrix] = create_syn_dataset(args.dataset, args.n_worker)
    [n_item, n_dim] = np.shape(feature_matrix)
    n_worker = np.shape(label_matrix)[1]
    n_class = np.max(true_label_list)
    print('# item, # dimension: ' + str(n_item) + ', ' + str(n_dim))
    print('# worker, # class: ' + str(n_worker) + ', ' + str(n_class))

    s_rates = args.s_rate.split(',')
    n_s_rate = len(s_rates)
    acc_dm_vec = np.zeros([args.n_rpt])
    acc_ci_vec = np.zeros([args.n_rpt])
    acc_ds_vec = np.zeros([args.n_rpt, n_s_rate])
    acc_dsdr_vec = np.zeros([args.n_rpt, n_s_rate])
    acc_mv_vec = np.zeros([args.n_rpt, n_s_rate])
    acc_mvdr_vec = np.zeros([args.n_rpt, n_s_rate])

    # 10-fold experiments
    for k in range(args.n_rpt):
        print('This is the ' + str(k + 1) + 'th fold.')

        # dataset split
        feature_matrix_tea, label_matrix_tea, feature_matrix_stu, label_matrix_stu, true_label_stu = split_teacher_student(
            feature_matrix,
            label_matrix,
            true_label_list,
            teacher_rate=args.teacher_rate)

        label_matrix_p = gen_pseduo_label_matrix(args, args.clf, feature_matrix_tea, label_matrix_tea, feature_matrix_stu)

        _, output_label_ds, confusion_matrix_ds, prior_probability_ds = dawid_skene(
            label_matrix_tea,
            tolerance=0.0001,
            max_iteration=200)

        # ====== DM with 0 cost ======
        pred_label_dm = direct_method(label_matrix_p, confusion_matrix_ds, prior_probability_ds)
        accuracy_dm = np.mean(pred_label_dm == true_label_stu)
        acc_dm_vec[k] = accuracy_dm

        # ====== CIL with 0 cost ======
        clf = tree.DecisionTreeClassifier()
        pred_label_ci = clf.fit(feature_matrix_tea, output_label_ds).predict(feature_matrix_stu)
        accuracy_ci = np.mean(pred_label_ci == true_label_stu)
        acc_ci_vec[k] = accuracy_ci

        for s in range(n_s_rate):
            label_matrix_stu_sampled = create_sampled_label_matrix(label_matrix_stu, s_rate=float(s_rates[s]))

            # ====== IS with increasing cost ======
            predicted_label_is = importance_sampling_ds(
                confusion_matrix_ds,
                prior_probability_ds,
                label_matrix_stu_sampled,
                s_rate=float(s_rates[s]))
            accuracy_is = np.mean(predicted_label_is == true_label_stu)
            acc_ds_vec[k, s] = accuracy_is

            # ====== MV with increasing cost ======
            predicted_label_mv = majority_voting(label_matrix_stu_sampled)
            accuracy_mv = np.mean(predicted_label_mv == true_label_stu)
            acc_mv_vec[k, s] = accuracy_mv

            # ====== DRC-DS with increasing cost ======
            predicted_label_drc_ds = doubly_robust_ds(
                label_matrix_p,
                confusion_matrix_ds,
                prior_probability_ds,
                label_matrix_stu_sampled,
                s_rate=float(s_rates[s]))
            accuracy_drc_ds = np.mean(predicted_label_drc_ds[0] == true_label_stu)
            acc_dsdr_vec[k, s] = accuracy_drc_ds

            # ====== DRC-MV with increasing cost ======
            predicted_label_drc_mv = doubly_robust_mv(
                label_matrix_p,
                label_matrix_stu_sampled,
                s_rate=float(s_rates[s]))
            accuracy_drc_mv = np.mean(predicted_label_drc_mv == true_label_stu)
            acc_mvdr_vec[k, s] = accuracy_drc_mv

    acc_dm = np.mean(acc_dm_vec)
    std_dm = 1.96 * np.std(acc_dm_vec) / np.sqrt(args.n_rpt)
    acc_ci = np.mean(acc_ci_vec)
    std_ci = 1.96 * np.std(acc_ci_vec) / np.sqrt(args.n_rpt)
    acc_ds = np.mean(acc_ds_vec, axis=0)
    std_ds = 1.96 * np.std(acc_ds_vec, axis=0) / np.sqrt(args.n_rpt)
    acc_drcds = np.mean(acc_dsdr_vec, axis=0)
    std_drcds = 1.96 * np.std(acc_dsdr_vec, axis=0) / np.sqrt(args.n_rpt)
    acc_mv = np.mean(acc_mv_vec, axis=0)
    std_mv = 1.96 * np.std(acc_mv_vec, axis=0) / np.sqrt(args.n_rpt)
    acc_drcmv = np.mean(acc_mvdr_vec, axis=0)
    std_drcmv = 1.96 * np.std(acc_mvdr_vec, axis=0) / np.sqrt(args.n_rpt)

    s = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    plt.figure(num=0, figsize=(6, 4), dpi=80, facecolor='w', edgecolor='k')
    plt.tick_params(labelsize=8)
    ax = plt.subplot(111)

    plt.errorbar(0.0, acc_dm, yerr=std_dm, c='k', fmt='-o', label='DM')
    plt.errorbar(0.0, acc_ci, yerr=std_ci, c='green', fmt='-o', label='CI')
    plt.errorbar(s, acc_ds, yerr=std_ds, c='cyan', fmt='-o', label='DS')
    plt.errorbar(s, acc_drcds, yerr=std_drcds, c='blue', fmt='-o', label='DRC-DS')
    plt.errorbar(s, acc_mv, yerr=std_mv, c='orange', fmt='-o', label='MV')
    plt.errorbar(s, acc_drcmv, yerr=std_drcmv, c='red', fmt='-o', label='DRC-MV')

    plt.legend(loc='lower right')
    plt.xlabel('Worker Sampling Rate')
    plt.ylabel('Accuracy')
    plt.title('On ' + str.upper(args.dataset) + ' dataset')
    plt.grid(True)
    plt.show()


if __name__ == '__main__':
    main()
