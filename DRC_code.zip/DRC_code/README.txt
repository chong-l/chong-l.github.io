This is the code package of the DRC paper [1].
Author: Chong Liu, chongliu@cs.ucsb.edu.
Created on Feb 19, 2022, last modified on Feb 19, 2022.

====== 1 What are the files? ======
drc.py: the main file used to run the code.
algs.py: the collection of all essential algorithms.
utils.py: the collection of all utility functions.
segment.txt: the Segment dataset from Libsvm [2].
segment_train_index.txt & segment_test_index.txt: fixed index assigning training and test.

====== 2 What are the requirments? ======
Python >= 3.6
sklearn
numpy
matplotlib

====== 3 How to use? ======
Simply run 'python3 drc.py'.

-d: assign the dataset name, default='segment'
-r: number of random trials, default=20
-w: number of workers, default=50
-c: type of classifier, default='dt', meanning decision tree
    --depth: depth of decision tree, default=3
-tr: teacher rate, default=0.5
-s: sampling rate, default='0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0'

====== References ======
[1] Chong Liu and Yu-Xiang Wang. Doubly robust crowdsourcing.
Journal of Artificial Intelligence Research (JAIR), 73:209-229, 2022.
[2] Chih-Chung Chang and Chih-Jen Lin. LIBSVM : a library for support vector machines.
ACM Transactions on Intelligent Systems and Technology (TIST), 2(3):1-27, 2011.
