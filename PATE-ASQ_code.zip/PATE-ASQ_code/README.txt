This is the code package of the Revisiting Model-Agnostic Private Learning paper [1].
It shows the PATE-Active Student Query (PATE-ASQ) algorithm.
Author: Chong Liu, chongliu@cs.ucsb.edu.
Created on Feb 19, 2022, last modified on Feb 19, 2022.

====== 1 What are the files? ======
pate_asq.py: the main file used to run the code.
mushrooms.txt: the Mushroom dataset from Libsvm [2].

====== 2 What are the requirments? ======
Python >= 3.6
autodp >= 0.2

====== 3 How to use? ======
Simply run 'python3 pate_asq.py'.

-r: number of random trials, default=30
-e': epsilon of DP parameters, default=1.0
-b': portion of active learning budget in terms of all queries, default=0.3

====== References ======
[1] Chong Liu, Yuqing Zhu, Kamalika Chaudhuri, and Yu-Xiang Wang.
Revisiting Model-Agnostic Private Learning: Faster Rates and Active Learning.
Journal of Machine Learning Research (JMLR), 22(262):1−44, 2021.
[2] Chih-Chung Chang and Chih-Jen Lin.
LIBSVM : a library for support vector machines.
ACM Transactions on Intelligent Systems and Technology (TIST), 2(3):1-27, 2011.
