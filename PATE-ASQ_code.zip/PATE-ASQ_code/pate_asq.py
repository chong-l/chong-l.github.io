"""
Main file for PATE with Active Student Queries
Author: Chong Liu, chongliu@cs.ucsb.edu
Created on Jun 4, 2021, last modified on Jul 17, 2021
"""

import argparse
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.datasets import load_svmlight_file
from autodp.mechanism_zoo import GaussianMechanism
from autodp.calibrator_zoo import eps_delta_calibrator

parser = argparse.ArgumentParser(description='PATE-PSQ-ASQ-P-NP Test')
parser.add_argument('-r', '--n_rpt', default=30, type=int)
parser.add_argument('-e', '--epsilon', default=1.0, type=float)
parser.add_argument('-b', '--al_budget', default=0.3, type=float)


def main():
    args = parser.parse_args()
    step_size0 = 0.05
    C_0 = 0.01

    result_np = np.zeros([args.n_rpt])
    result_pate_psq = np.zeros([args.n_rpt])
    result_pate_asq = np.zeros([args.n_rpt, 2])
    result_pate_asq_np = np.zeros([args.n_rpt, 2])

    feature, label = load_svmlight_file('mushrooms.txt')
    feature = feature.todense()
    label = 2 * (label - 1.5 * np.ones([np.shape(feature)[0]]))

    n_all, n_dim = np.shape(feature)
    print('# instance, # dimension: ' + str(n_all) + ', ' + str(n_dim))

    X_t, X_s, y_t, y_s = train_test_split(feature, label, test_size=0.2)
    X_sl, X_su, y_sl, y_su = train_test_split(X_s, y_s, test_size=0.1)

    delta = 1.0 / np.shape(X_t)[0]
    n_teacher_points = np.shape(X_t)[0]
    K = int(np.round(n_teacher_points / 100))
    n_unlabel = np.shape(X_su)[0]
    n_test = np.shape(X_sl)[0]
    c0 = C_0 * n_unlabel
    n_ell = np.round(args.al_budget * n_unlabel)

    class PATE(GaussianMechanism):
        def __init__(self, sigma, m, Binary, name='PATE'):
            # sigma is the noise added
            if Binary:
                # This is a binary classification task
                sensitivity = 1
            else:  # for the multiclass case, the L2 sensitivity is sqrt(2)
                sensitivity = np.sqrt(2)
            GaussianMechanism.__init__(self, sigma=sigma / np.sqrt(m) / sensitivity, name=name)
            self.params = {'sigma': sigma}

    calibrate = eps_delta_calibrator()

    class PATE_binary_psq(PATE):
        def __init__(self, sigma, name='PATE_psq'):
            PATE.__init__(self, sigma=sigma, m=n_unlabel, Binary=True, name=name)

    class PATE_binary_asq(PATE):
        def __init__(self, sigma, name='PATE_asq'):
            PATE.__init__(self, sigma=sigma, m=n_ell, Binary=True, name=name)

    mech_psq = calibrate(PATE_binary_psq, args.epsilon, delta, [0, n_unlabel], name='PATE_psq')
    mech_asq = calibrate(PATE_binary_asq, args.epsilon, delta, [0, n_ell], name='PATE_asq')
    sigma = mech_psq.params['sigma']
    sigma_asq = mech_asq.params['sigma']
    print('# Teacher points, student unlabeled, test: ' + str(n_teacher_points) + ', ' + str(n_unlabel) + ', ' + str(
        n_test))

    for rpt in range(args.n_rpt):

        print('This is the ' + str(rpt+1) + '-th/' + str(args.n_rpt) + ' repeat')
        X_t, X_s, y_t, y_s = train_test_split(feature, label, test_size=0.2)
        X_sl, X_su, y_sl, y_su = train_test_split(X_s, y_s, test_size=0.1)
        teacher_idx = np.random.randint(K, size=np.shape(X_t)[0])

        # train teacher classifiers
        clf_t = []
        for k in range(K):
            X_t_cur = X_t[teacher_idx == k]
            y_t_cur = y_t[teacher_idx == k]
            reg = LinearRegression().fit(X_t_cur, y_t_cur)
            clf_t.append(reg.coef_)

        # PATE-PSQ non-private
        y_hat_su_np = np.zeros([n_unlabel])
        for i in range(n_unlabel):
            y_hat_su_np[i] = teachers_predict(clf_t, 0.0, X_su[i])

        clf_s_np = LinearRegression().fit(X_su, y_hat_su_np)
        y_pred_s_np = clf_s_np.predict(X_sl)
        y_pred_s_np = binary_rounding(y_pred_s_np)
        acc_s = np.mean(y_sl == y_pred_s_np)
        result_np[rpt] = acc_s

        # PATE-PSQ Gaussian mechanism
        y_hat_su = np.zeros([n_unlabel])
        for i in range(n_unlabel):
            g_var = np.random.normal(0.0, sigma)
            y_hat_su[i] = teachers_predict(clf_t, g_var, X_su[i])

        clf_s = LinearRegression().fit(X_su, y_hat_su)
        y_pred_s = clf_s.predict(X_sl)
        y_pred_s = binary_rounding(y_pred_s)
        acc_s_psq = np.mean(y_sl == y_pred_s)
        result_pate_psq[rpt] = acc_s_psq

        w_asq_np, c_np = pate_asq(clf_t, args.epsilon, delta, X_su, c0, step_size0, args.al_budget, priv=False)
        w_asq, c = pate_asq(clf_t, args.epsilon, delta, X_su, c0, step_size0, args.al_budget, priv=True)

        y_pred_s_asq_np = np.zeros([n_test])
        for i in range(n_test):
            y_pred_s_asq_np[i] = predict(w_asq_np, X_sl[i])
        y_pred_s_asq_np = binary_rounding(y_pred_s_asq_np)
        acc_s_asq_np = np.mean(y_sl == y_pred_s_asq_np)
        result_pate_asq_np[rpt, 0] = acc_s_asq_np
        result_pate_asq_np[rpt, 1] = c_np

        y_pred_s_asq = np.zeros([n_test])
        for i in range(n_test):
            y_pred_s_asq[i] = predict(w_asq, X_sl[i])
        y_pred_s_asq = binary_rounding(y_pred_s_asq)
        acc_s_asq = np.mean(y_sl == y_pred_s_asq)
        result_pate_asq[rpt, 0] = acc_s_asq
        result_pate_asq[rpt, 1] = c

    print('Active learning budget: ' + str(n_ell))
    print('Epsilon is: ' + str(args.epsilon))
    print('1/Delta is: ' + str(1.0/delta))
    print('Sigma is: ' + str(sigma))
    print('Sigma_asq is: ' + str(sigma_asq))

    print('PATE-PSQ-NP acc is: ' + str(evaluate(result_np)))
    print('PATE-ASQ-NP acc is: ' + str(evaluate(result_pate_asq_np[:, 0])))
    print('PATE-ASQ-NP budget used: ' + str(evaluate(result_pate_asq_np[:, 1])))

    print('PATE-PSQ acc is: ' + str(evaluate(result_pate_psq)))
    pate_mech_psq = PATE(sigma=sigma, m=n_unlabel, Binary=True, name='PATE')
    eps_psq = pate_mech_psq.get_approxDP(delta)
    print('eps_psq_expost is: ' + str(eps_psq))

    print('PATE-ASQ acc is: ' + str(evaluate(result_pate_asq[:, 0])))
    print('PATE-ASQ budget used: ' + str(evaluate(result_pate_asq[:, 1])))
    m_asq, _ = evaluate(result_pate_asq[:, 1])
    pate_mech_asq = PATE(sigma=sigma_asq, m=m_asq, Binary=True, name='PATE')
    eps_asq = pate_mech_asq.get_approxDP(delta)
    print('eps_asq_expost is: ' + str(eps_asq))


def predict(w, x):
    ret = np.inner(w, x)
    if ret >= 0:
        ret = 1
    else:
        ret = -1
    return ret


def teachers_predict(clf_t, gau_var, x):
    preds_t = 0.0
    for k in range(len(clf_t)):
        if predict(clf_t[k], x) > 0:
            preds_t += 1
    if preds_t + gau_var >= 0.5 * len(clf_t):
        return 1
    else:
        return -1


def binary_rounding(y_vector):
    for i in range(np.shape(y_vector)[0]):
        if y_vector[i] > 0:
            y_vector[i] = 1
        else:
            y_vector[i] = -1
    return y_vector


def evaluate(result_vector):
    acc = np.mean(result_vector)
    std = 1.96 * np.std(result_vector) / np.shape(result_vector)[0]
    return acc, std


def pate_asq(clf_t, eps, delta, X_su, c0, step_size0, asq_rate, priv):
    n_unlabel, n_dim = np.shape(X_su)
    n_ell = np.round(asq_rate * n_unlabel)
    sigma_asq = (np.sqrt(2 * n_ell * np.log(1 / delta)) + np.sqrt(2 * n_ell * np.log(1 / delta) + 2 * eps * n_ell)) / (
                2 * eps)
    w_asq = np.zeros([n_dim])

    sum_loss = 1
    c = 1
    for i in range(n_unlabel):
        n_i = np.floor(np.log2(i + 1)) + 1
        x = X_su[i]
        if priv == True:
            g_var = np.random.normal(0.0, sigma_asq)
        else:
            g_var = 0.0

        pred = predict(w_asq, x)
        step_size = np.sqrt(step_size0 / (step_size0 + i))
        squared_norm = np.inner(x, x)
        if step_size * squared_norm > 0:
            gap = np.abs(np.inner(w_asq, x)) / (step_size * squared_norm)
            threshold = np.sqrt(c0 * sum_loss / c / n_i) + c0 * np.log(n_i) / n_i
            if gap <= threshold:
                c += 1
                if c >= n_ell:
                    break
                y = teachers_predict(clf_t, g_var, x)
                if y != pred:
                    sum_loss += 1
                exp = step_size * squared_norm
                if exp < 1e-6:
                    weight = 2 * (pred - y) * step_size
                else:
                    weight = (pred - y) * (1.0 - np.exp(-2.0 * exp)) / squared_norm
                w_asq = w_asq - weight * x
    return w_asq, c


if __name__ == "__main__":
    main()
